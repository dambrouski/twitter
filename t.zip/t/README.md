#twitter challenge

This email contains three files:
1) executable java jar
2) this readme with details about the program
3) compressed project directory, all source files are under src/main/java directory. Runner.java is the entry point the
program.

Environment:
this program does not have dependencies except for latest version of java 8. This is the version I've been running
on my laptop:
java -version
java version "1.8.0_112"
But any other java version should do it.

How to run program:
download attached jar file java -jar t-1.0-SNAPSHOT.jar to your current working directory. Program requires minimum
two parameters to run:
1) absolute path to server list file on your machine
2) absolute path to machine readable file on your machine for output
below is a sample command
java -jar t-1.0-SNAPSHOT.jar /Users/aliaksandrdambrouski/development/twitter/servers.txt /Users/aliaksandrdambrouski/development/twitter/downstream.txt

Additionally you can also pass:
- 3rd parameter to your program maxServerReaders (how many threads are reading .json application data concurrently from server list) - this equals to number of available CPUs on the executing host by default
to override pass 3 argument to the program, e.g.:
java -jar t-1.0-SNAPSHOT.jar /Users/aliaksandrdambrouski/development/twitter/servers.txt /Users/aliaksandrdambrouski/development/twitter/downstream.txt 10

- 4th system property will override how many threads will aggregate success rate data by application by version,
by default it runs at #cpus on the executing host, but can be overridden like below
java -Djava.util.concurrent.ForkJoinPool.common.parallelism=16 -jar t-1.0-SNAPSHOT.jar /Users/aliaksandrdambrouski/development/twitter/servers.txt /Users/aliaksandrdambrouski/development/twitter/downstream.txt 10

Project files:
all project source files are in a twitter.zip file under src/main/java directory. Main method is inside Runner.java

Short program summary:
Program load list of servers into memory.
Initializes a thread pool to start reading json files from mulitple servers at once and write json output into thread safe queue.

Once application data is downloaded from servers we calculate application success rate and group data
by application by version with in parallel - default number of threads # of cpus in the executing host minus one thread

Once grouping and success rate calculation data program start two threads in parallel -> one is writing data in a human
readable tabular format to the stdout and the other writing as json file to be later consumed by downstream system.

once both operations are complete program exits.

If you would like to make modification to the program either install gradle and run

gradle build
gradle jar

to produce a new jar.

Or I recommend installing Intellij and run gradle tasks build and jar via Intellij IDE.
jar file would be under build/libs directory

Sample output and arguments:

java -Djava.util.concurrent.ForkJoinPool.common.parallelism=16 -jar t-1.0-SNAPSHOT.jar /Users/aliaksandrdambrouski/development/twitter/servers.txt /Users/aliaksandrdambrouski/development/twitter/downstream.txt 10
|         Application|             Version|        Success Rate|
|              Cache2|               1.0.1|               0.400|
|             Webapp1|               1.2.2|               0.625|
Program completed...

cat downstream.txt
[{"application":"Cache2","version":"1.0.1","successRate":0.4},{"application":"Webapp1","version":"1.2.2","successRate":0.625}]

cat downstream.txt
[{"application":"Cache2","version":"1.0.1","sucat servers.txt
https://raw.githubusercontent.com/dambrouski/twitter/master/simple.json
https://raw.githubusercontent.com/dambrouski/twitter/master/simple2.json
https://raw.githubusercontent.com/dambrouski/twitter/master/simple3.json



