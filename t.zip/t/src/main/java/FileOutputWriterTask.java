import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

public class FileOutputWriterTask implements Runnable {

    private String outputFile;
    private List<ApplicationSuccessRateByVersion> applicationSuccessRateByVersionList;

    public FileOutputWriterTask(String outputFile, List<ApplicationSuccessRateByVersion> applicationSuccessRateByVersionList) {
        this.outputFile = outputFile;
        this.applicationSuccessRateByVersionList = applicationSuccessRateByVersionList;
    }

    @Override
    public void run() {
        Gson gson = new GsonBuilder().create();
        try (FileWriter fileWriter = new FileWriter(outputFile)){
            gson.toJson(applicationSuccessRateByVersionList.toArray(), fileWriter);
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}
