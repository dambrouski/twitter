import java.io.IOException;
import java.util.*;
import java.util.concurrent.*;

public class Runner {

    public static void main(String[] args) {

        if (args.length < 2) {
            System.err.println("Invalid number of arguments, at least two arguments required: java -jar t-1.0-SNAPSHOT.jar [path-to-server.txt] [path-to-application-by-version-by-success-rate-file]");
            System.exit(1);
        }

        try {

            String serverFile = args[0];
            String outputFile = args[1];

            int maxServerReaders = Runtime.getRuntime().availableProcessors();
            if (args.length == 3) {
                maxServerReaders = Integer.parseInt(args[2]);
            }

            Queue<Collection<ApplicationStatus>> queue = new ConcurrentLinkedQueue<>();
            //gets list of server from serverFile
            ServerListReader serverListReader = new ServerListReader(serverFile);
            List<String> endpointList = serverListReader.getServerEndpointsServers();

            //read data from server endpoints and add to common queue with #maxServerReaders parallelism
            ExecutorService executorService = Executors.newFixedThreadPool(maxServerReaders);
            for (String endpoint : endpointList) {
                executorService.submit(new ServerReaderTask(queue, endpoint));
            }
            executorService.shutdown();
            executorService.awaitTermination(1_000_000L, TimeUnit.SECONDS);

            //#2 group records with default parallelism of #cpus on the executing host, can be increased by setting
            // following sys prop e.g.: -Djava.util.concurrent.ForkJoinPool.common.parallelism=16
            DataAggregator dataAggregator = new DataAggregator(queue);
            List<ApplicationSuccessRateByVersion> aggregatedData = dataAggregator.aggregateData();

            //Write to stdout and downstream system file outputFile in parallel to speed up
            ExecutorService outputExecutorService = Executors.newFixedThreadPool(2);
            //#3 send to standard output
            outputExecutorService.submit(new StandardOutputPrinterTask(aggregatedData));
            //#4 write to file
            outputExecutorService.submit(new FileOutputWriterTask(outputFile, aggregatedData));
            outputExecutorService.shutdown();
            outputExecutorService.awaitTermination(1_000_000L, TimeUnit.SECONDS);
            System.out.println("Program completed...");


        } catch (IOException e) {
            System.out.println("Critical IO Error error");
            e.printStackTrace();
            System.exit(1);
        } catch (Exception e) {
            System.out.println("Critical error");
            e.printStackTrace();
            System.exit(1);
        }

    }


}
