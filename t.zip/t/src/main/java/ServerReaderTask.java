import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import org.apache.log4j.Logger;

import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.Type;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Collection;
import java.util.Queue;

public class ServerReaderTask implements Runnable {

    final static Logger logger = Logger.getLogger(ServerReaderTask.class);

    private Queue<Collection<ApplicationStatus>> queue;
    private String endpoint;

    ServerReaderTask(Queue<Collection<ApplicationStatus>> queue, String endpoint) {
        this.queue = queue;
        this.endpoint = endpoint;
    }

    @Override
    public void run() {
        Gson gson = new Gson();
        URL url;
        try {
            url = new URL(endpoint);
            InputStreamReader reader = new InputStreamReader(url.openStream());
            Type myDataType = new TypeToken<Collection<ApplicationStatus>>() {
            }.getType();
            Collection<ApplicationStatus> myData = gson.fromJson(reader, myDataType);
            queue.offer(myData);
        } catch (MalformedURLException e) {
            logger.error("Invalid server endpoint url " + endpoint);
        } catch (IOException e) {
            logger.error("Failed to read server " + endpoint);
        }

    }
}
