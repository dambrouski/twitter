import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class ServerListReader {
    private String serverFile;

    public ServerListReader(String serverFile) {
        this.serverFile = serverFile;
    }

    List<String> getServerEndpointsServers() throws IOException {
        File serverFile = new File(this.serverFile);
        if (!serverFile.exists()) {
            throw new RuntimeException(String.format("Server file does not exist %s", serverFile));
        }
        if (!serverFile.canRead()) {
            throw new RuntimeException(String.format("Server file is not readable %s", serverFile));
        }

        List<String> serverList = new ArrayList<>();

        InputStreamReader fileReader = new FileReader(serverFile);
        try (BufferedReader reader =
                     new BufferedReader(fileReader)) {
            String serverEndpoint = null;
            while ((serverEndpoint = reader.readLine()) != null) {
                serverList.add(serverEndpoint);
            }
        }

        return serverList;

    }
}
