/**
 * Created by aliaksandrdambrouski on 11/28/19.
 */
public class ApplicationStatus {
    private String Application;
    private String Version;
    private long Request_Count;
    private long Success_Count;

    public String getApplication() {
        return Application;
    }

    public void setApplication(String application) {
        Application = application;
    }

    public long getRequest_Count() {
        return Request_Count;
    }

    public void setRequest_Count(long request_Count) {
        Request_Count = request_Count;
    }

    public long getSuccess_Count() {
        return Success_Count;
    }

    public void setSuccess_Count(long success_Count) {
        Success_Count = success_Count;
    }

    public String getVersion() {
        return Version;
    }

    public void setVersion(String version) {
        this.Version = version;
    }
}