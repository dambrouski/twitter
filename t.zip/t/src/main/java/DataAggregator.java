import java.util.*;
import java.util.stream.Collectors;


public class DataAggregator {
    Queue<Collection<ApplicationStatus>> queue;

    public DataAggregator(Queue<Collection<ApplicationStatus>> queue) {
        this.queue = queue;
    }

    public List<ApplicationSuccessRateByVersion> aggregateData() {
        return queue.stream().parallel().flatMap(Collection::stream).collect(
                Collectors.groupingBy(ApplicationStatus::getApplication,
                        Collectors.groupingBy(ApplicationStatus::getVersion, Collectors.reducing((applicationStatus1, applicationStatus2) -> {
                            applicationStatus1.setSuccess_Count(applicationStatus1.getSuccess_Count() + applicationStatus2.getSuccess_Count());
                            applicationStatus1.setRequest_Count(applicationStatus1.getRequest_Count() + applicationStatus2.getRequest_Count());
                            return applicationStatus1;
                        })))).values().stream().map(Map::values).
                flatMap(Collection::stream).filter(Optional::isPresent).
                map(Optional::get).map(applicationStatus -> {
            Double succesRate = null;
            if (applicationStatus.getRequest_Count() == 0) {
                succesRate = 0.0d;
            } else {
                succesRate = (double) applicationStatus.getSuccess_Count() / (double) applicationStatus.getRequest_Count();
            }
            return new ApplicationSuccessRateByVersion(applicationStatus.getApplication(), applicationStatus.getVersion(), succesRate);
        }).collect(Collectors.toList());
    }
}
