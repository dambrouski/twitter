import io.bretty.console.table.Alignment;
import io.bretty.console.table.ColumnFormatter;
import io.bretty.console.table.Table;

import java.util.List;

public class StandardOutputPrinterTask implements Runnable {

    private List<ApplicationSuccessRateByVersion> applicationSuccessRateByVersionList;
    private static String[] header = new String[]{"Application", "Version", "Success Rate"};

    public StandardOutputPrinterTask(List<ApplicationSuccessRateByVersion> applicationSuccessRateByVersionList) {
        this.applicationSuccessRateByVersionList = applicationSuccessRateByVersionList;
    }

    @Override
    public void run() {
        String[][] rows = applicationSuccessRateByVersionList.stream().map(
                applicationSuccessRateByVersion -> new String[]{applicationSuccessRateByVersion.getApplication(), applicationSuccessRateByVersion.getVersion(), String.format("%.3f", applicationSuccessRateByVersion.getSuccessRate())}
        ).toArray(String[][]::new);
        System.out.println(Table.of(header, rows, ColumnFormatter.text(Alignment.RIGHT, 20)));
    }
}