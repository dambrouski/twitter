/**
 * Created by aliaksandrdambrouski on 11/28/19.
 */
public class ApplicationSuccessRateByVersion {
    private String application;
    private String version;
    private Double successRate;

    public ApplicationSuccessRateByVersion(String application, String version, Double successRate) {
        this.application = application;
        this.version = version;
        this.successRate = successRate;
    }

    public String getApplication() {
        return application;
    }

    public String getVersion() {
        return version;
    }

    public Double getSuccessRate() {
        return successRate;
    }
}
